"""CORTEX local test suite."""
